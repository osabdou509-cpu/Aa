package com.example.engine

import android.content.Intent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object MediaProjectionHolder {
    private val _hasPermission = MutableStateFlow(false)
    val hasPermission = _hasPermission.asStateFlow()

    var resultCode: Int = 0
        private set
    var resultData: Intent? = null
        private set

    fun setProjectionData(code: Int, data: Intent?) {
        resultCode = code
        resultData = data
        _hasPermission.value = (code != 0 && data != null)
    }

    fun clear() {
        resultCode = 0
        resultData = null
        _hasPermission.value = false
    }
}
