package com.example.engine

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.view.Choreographer
import com.example.data.FpsMetrics
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.ArrayDeque
import kotlin.math.roundToInt

class FpsMeasurementEngine private constructor() {

    private val _metrics = MutableStateFlow(FpsMetrics())
    val metrics: StateFlow<FpsMetrics> = _metrics.asStateFlow()

    private var handlerThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    // Frame timestamps sliding window (last 1000ms)
    private val frameTimestamps = ArrayDeque<Long>(200)
    private val frameDurationsMs = ArrayList<Float>(200)
    private var lastFrameTimeNs: Long = 0L
    private var totalFramesCount: Long = 0L

    // In-app fallback/preview choreographer
    private var choreographer: Choreographer? = null
    private var choreographerCallback: Choreographer.FrameCallback? = null
    private var isUsingVirtualDisplay = false

    // Simulation / Benchmark override (if active)
    @Volatile
    private var simulationTargetFps: Int? = null

    @Volatile
    private var isSimulatingFreeze: Boolean = false

    private val watchdogRunnable = object : Runnable {
        override fun run() {
            checkFreezeTimeout()
            backgroundHandler?.postDelayed(this, 100)
        }
    }

    fun startVirtualDisplay(projection: MediaProjection) {
        stopVirtualDisplay()
        stopChoreographerPreview()

        val thread = HandlerThread("FpsVirtualDisplayThread").apply { start() }
        handlerThread = thread
        val handler = Handler(thread.looper)
        backgroundHandler = handler

        mediaProjection = projection

        // Register MediaProjection Callback (Required on Android 14+)
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopVirtualDisplay()
            }
        }, handler)

        // 1x1 Pixel micro VirtualDisplay as requested in blueprint
        val reader = ImageReader.newInstance(1, 1, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ ir ->
            try {
                val image = ir.acquireLatestImage()
                if (image != null) {
                    val nowNs = System.nanoTime()
                    // Immediately close image without converting to Bitmap (Zero CPU / RAM overhead)
                    image.close()

                    if (!isSimulatingFreeze) {
                        onNewFrameDispatched(nowNs)
                    }
                }
            } catch (_: Exception) {
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "Fps1x1VirtualDisplay",
            1, // 1 px width
            1, // 1 px height
            1, // 1 dpi
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        isUsingVirtualDisplay = true
        _metrics.update { it.copy(isVirtualDisplayActive = true) }

        // Start Watchdog to detect 0 FPS
        handler.post(watchdogRunnable)
    }

    fun stopVirtualDisplay() {
        backgroundHandler?.removeCallbacks(watchdogRunnable)
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (_: Exception) {}
        imageReader = null

        try {
            mediaProjection?.stop()
        } catch (_: Exception) {}
        mediaProjection = null

        handlerThread?.quitSafely()
        handlerThread = null
        backgroundHandler = null

        isUsingVirtualDisplay = false
        _metrics.update { it.copy(isVirtualDisplayActive = false) }
    }

    /**
     * In-app preview frame listener when VirtualDisplay is not running.
     * Ensures live preview functions inside the app immediately.
     */
    fun startChoreographerPreview() {
        if (isUsingVirtualDisplay || choreographerCallback != null) return

        choreographer = Choreographer.getInstance()
        var lastChoreographerNs = 0L

        choreographerCallback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (isUsingVirtualDisplay) return

                if (!isSimulatingFreeze) {
                    val targetFps = simulationTargetFps
                    if (targetFps != null && targetFps > 0) {
                        // Throttled frame simulation
                        val frameIntervalNs = (1_000_000_000.0 / targetFps).toLong()
                        if (frameTimeNanos - lastChoreographerNs >= frameIntervalNs) {
                            lastChoreographerNs = frameTimeNanos
                            onNewFrameDispatched(frameTimeNanos)
                        }
                    } else {
                        onNewFrameDispatched(frameTimeNanos)
                    }
                }

                // Check 0 FPS timeout
                checkFreezeTimeout()

                choreographer?.postFrameCallback(this)
            }
        }

        choreographer?.postFrameCallback(choreographerCallback)
    }

    fun stopChoreographerPreview() {
        choreographerCallback?.let { choreographer?.removeFrameCallback(it) }
        choreographerCallback = null
    }

    private fun onNewFrameDispatched(nowNs: Long) {
        synchronized(frameTimestamps) {
            val prevNs = lastFrameTimeNs
            lastFrameTimeNs = nowNs
            totalFramesCount++

            val windowStartNs = nowNs - 1_000_000_000L // 1000ms sliding window
            frameTimestamps.addLast(nowNs)

            while (frameTimestamps.isNotEmpty() && frameTimestamps.first() < windowStartNs) {
                frameTimestamps.removeFirst()
            }

            val avgFps = frameTimestamps.size.toFloat()
            val dtNs = if (prevNs > 0) (nowNs - prevNs) else 0L
            val frameTimeMs = if (dtNs > 0) dtNs / 1_000_000f else 0f
            val instantFps = if (dtNs > 0) (1_000_000_000.0 / dtNs).toFloat() else avgFps

            // 1% Low calculation from recent frame durations
            frameDurationsMs.add(frameTimeMs)
            if (frameDurationsMs.size > 120) {
                frameDurationsMs.removeAt(0)
            }

            val onePercentLowFps: Float
            if (frameDurationsMs.size >= 10) {
                val sorted = frameDurationsMs.sorted()
                val p99Index = (sorted.size * 0.99f).roundToInt().coerceIn(0, sorted.size - 1)
                val worstFrameMs = sorted[p99Index]
                onePercentLowFps = if (worstFrameMs > 0.1f) {
                    (1000f / worstFrameMs).coerceAtMost(avgFps)
                } else {
                    avgFps
                }
            } else {
                onePercentLowFps = avgFps
            }

            // Update history (last 30 samples)
            val currentHistory = _metrics.value.history
            val updatedHistory = (currentHistory + avgFps).takeLast(30)

            _metrics.value = FpsMetrics(
                averageFps = avgFps,
                instantFps = instantFps,
                onePercentLowFps = onePercentLowFps,
                frameTimeMs = frameTimeMs,
                frameCount = totalFramesCount,
                isFrozen = false,
                isVirtualDisplayActive = isUsingVirtualDisplay,
                history = updatedHistory
            )
        }
    }

    private fun checkFreezeTimeout() {
        val nowNs = System.nanoTime()
        val elapsedNs = if (lastFrameTimeNs > 0) nowNs - lastFrameTimeNs else 0L

        // If > 500 ms without any new frame, the game/screen is frozen -> 0 FPS
        if (lastFrameTimeNs > 0 && elapsedNs > 500_000_000L) {
            synchronized(frameTimestamps) {
                frameTimestamps.clear()
                frameDurationsMs.clear()

                val currentHistory = _metrics.value.history
                val updatedHistory = (currentHistory + 0f).takeLast(30)

                _metrics.value = _metrics.value.copy(
                    averageFps = 0f,
                    instantFps = 0f,
                    onePercentLowFps = 0f,
                    frameTimeMs = elapsedNs / 1_000_000f,
                    isFrozen = true,
                    history = updatedHistory
                )
            }
        }
    }

    // Benchmark / Stress testing simulator
    fun setSimulationTargetFps(fps: Int?) {
        simulationTargetFps = fps
    }

    fun triggerSimulatedFreeze(durationMs: Long = 2000L) {
        isSimulatingFreeze = true
        val handler = backgroundHandler ?: Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            isSimulatingFreeze = false
        }, durationMs)
    }

    companion object {
        val instance by lazy { FpsMeasurementEngine() }
    }
}
