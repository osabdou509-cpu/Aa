package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FpsMetrics
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.DangerRed
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun FrameGraphView(
    metrics: FpsMetrics,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("metrics_and_graph_section")
    ) {
        // 3 Key Metrics Cards Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard(
                title = "متوسط FPS",
                value = "${metrics.averageFps.roundToInt()}",
                unit = "fps",
                accentColor = NeonGreen,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "1% Low (تقطيع)",
                value = "${metrics.onePercentLowFps.roundToInt()}",
                unit = "fps",
                accentColor = CyberCyan,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "زمن الإطار",
                value = String.format(Locale.US, "%.1f", metrics.frameTimeMs),
                unit = "ms",
                accentColor = if (metrics.frameTimeMs > 25f) DangerRed else Color(0xFFB388FF),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Real-time Canvas Graph
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CyberSurface)
                .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مخطط استقرار الإطارات (Real-Time Wave)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )

                    Text(
                        text = "إجمالي: ${metrics.frameCount}",
                        fontSize = 11.sp,
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val history = metrics.history
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                ) {
                    val w = size.width
                    val h = size.height

                    // Grid lines (30, 60, 120 FPS guides)
                    val fpsLevels = listOf(30f, 60f, 120f)
                    val maxScale = 144f

                    fpsLevels.forEach { fpsVal ->
                        val y = h - (fpsVal / maxScale * h)
                        drawLine(
                            color = Color(0xFF1E293B),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    if (history.size >= 2) {
                        val path = Path()
                        val fillPath = Path()
                        val stepX = w / (history.size - 1).coerceAtLeast(1)

                        val firstY = h - (history[0].coerceIn(0f, maxScale) / maxScale * h)
                        path.moveTo(0f, firstY)
                        fillPath.moveTo(0f, h)
                        fillPath.lineTo(0f, firstY)

                        for (i in 1 until history.size) {
                            val currentX = i * stepX
                            val currentY = h - (history[i].coerceIn(0f, maxScale) / maxScale * h)
                            path.lineTo(currentX, currentY)
                            fillPath.lineTo(currentX, currentY)
                        }

                        fillPath.lineTo(w, h)
                        fillPath.close()

                        // Gradient Area Fill
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    NeonGreen.copy(alpha = 0.25f),
                                    Color.Transparent
                                )
                            )
                        )

                        // Graph Line
                        drawPath(
                            path = path,
                            brush = Brush.horizontalGradient(
                                listOf(CyberCyan, NeonGreen)
                            ),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    unit: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CyberSurface)
            .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = accentColor,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = unit,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
            }
        }
    }
}
