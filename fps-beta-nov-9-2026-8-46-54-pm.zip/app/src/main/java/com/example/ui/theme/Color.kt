package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Gaming Dark Palette
val CyberBackground = Color(0xFF090D16)
val CyberSurface = Color(0xFF111827)
val CyberSurfaceElevated = Color(0xFF1E293B)
val CyberSurfaceBorder = Color(0xFF334155)

// Accent Colors
val NeonGreen = Color(0xFF00E676)
val CyberCyan = Color(0xFF00E5FF)
val ElectricPurple = Color(0xFF7C4DFF)
val FlameAmber = Color(0xFFFFB300)
val DangerRed = Color(0xFFFF5252)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Material 3 defaults compatibility
val Purple80 = CyberCyan
val PurpleGrey80 = Color(0xFF64748B)
val Pink80 = ElectricPurple

val Purple40 = Color(0xFF0284C7)
val PurpleGrey40 = Color(0xFF334155)
val Pink40 = Color(0xFF5B21B6)
