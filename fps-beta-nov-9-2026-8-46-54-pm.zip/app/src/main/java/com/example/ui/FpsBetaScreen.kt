package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.FpsMetrics
import com.example.data.OverlayConfig
import com.example.ui.components.AnimatedWelcomeCard
import com.example.ui.components.BenchmarkSimulatorCard
import com.example.ui.components.FpsSpeedometerGauge
import com.example.ui.components.FrameGraphView
import com.example.ui.components.OverlaySettingsCard
import com.example.ui.components.PermissionsSection
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.DangerRed
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.FpsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FpsBetaScreen(
    viewModel: FpsViewModel,
    onRequestOverlayPermission: () -> Unit,
    onRequestMediaProjection: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val isOverlayRunning by viewModel.isOverlayServiceRunning.collectAsStateWithLifecycle()
    val isTouchLocked by viewModel.isTouchLocked.collectAsStateWithLifecycle()
    val hasOverlayPerm by viewModel.hasOverlayPermission.collectAsStateWithLifecycle()
    val hasMediaProjectionPerm by viewModel.hasMediaProjectionPermission.collectAsStateWithLifecycle()
    val hasNotifPerm by viewModel.hasNotificationPermission.collectAsStateWithLifecycle()
    val config by viewModel.overlayConfig.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.statusBars,
        containerColor = CyberBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "fps beta",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary,
                            fontFamily = FontFamily.SansSerif,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "PRO",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = NeonGreen
                            )
                        }
                    }
                },
                actions = {
                    // Overlay Status Pill
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isOverlayRunning) NeonGreen.copy(alpha = 0.15f) else Color(0xFF1E293B)
                            )
                            .border(
                                1.dp,
                                if (isOverlayRunning) NeonGreen.copy(alpha = 0.5f) else Color.Transparent,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isOverlayRunning) NeonGreen else TextSecondary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isOverlayRunning) "النافذة نشطة" else "النافذة متوقفة",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isOverlayRunning) NeonGreen else TextSecondary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberBackground,
                    titleContentColor = TextPrimary
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .widthIn(max = 640.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Animated Greeting for user
            item {
                AnimatedWelcomeCard()
            }

            // 2. Speedometer Gauge with 0 - 144 FPS
            item {
                FpsSpeedometerGauge(metrics = metrics)
            }

            // 3. Frame Time Graph & Key Metrics Grid
            item {
                FrameGraphView(metrics = metrics)
            }

            // 4. Primary Floating Overlay Start/Stop Card
            item {
                MasterOverlayActionCard(
                    isRunning = isOverlayRunning,
                    hasPermissions = hasOverlayPerm && hasMediaProjectionPerm,
                    isTouchLocked = isTouchLocked,
                    onToggleOverlay = {
                        if (!hasOverlayPerm) {
                            onRequestOverlayPermission()
                        } else if (!hasMediaProjectionPerm) {
                            onRequestMediaProjection()
                        } else {
                            viewModel.toggleOverlayService()
                        }
                    },
                    onToggleLock = { viewModel.toggleTouchLock() }
                )
            }

            // 5. System Permissions Section
            item {
                PermissionsSection(
                    hasOverlayPermission = hasOverlayPerm,
                    hasMediaProjectionPermission = hasMediaProjectionPerm,
                    hasNotificationPermission = hasNotifPerm,
                    onRequestOverlayPermission = onRequestOverlayPermission,
                    onRequestMediaProjection = onRequestMediaProjection,
                    onRequestNotificationPermission = onRequestNotificationPermission
                )
            }

            // 6. Benchmark & Screen Freeze Simulator
            item {
                BenchmarkSimulatorCard(
                    onSelectTargetFps = { target -> viewModel.setSimulationTargetFps(target) },
                    onTriggerFreeze = { viewModel.triggerSimulatedFreeze() }
                )
            }

            // 7. Overlay Appearance & Behavior Customization
            item {
                OverlaySettingsCard(
                    config = config,
                    isTouchLocked = isTouchLocked,
                    onConfigChange = { newConfig -> viewModel.updateOverlayConfig(newConfig) },
                    onToggleTouchLock = { viewModel.toggleTouchLock() }
                )
            }

            // 8. Technical Architecture Blueprint Info Card
            item {
                BlueprintInfoCard()
            }
        }
    }
}

@Composable
private fun MasterOverlayActionCard(
    isRunning: Boolean,
    hasPermissions: Boolean,
    isTouchLocked: Boolean,
    onToggleOverlay: () -> Unit,
    onToggleLock: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("master_overlay_action_card")
            .clip(RoundedCornerShape(22.dp))
            .background(CyberSurface)
            .border(
                1.5.dp,
                if (isRunning) NeonGreen.copy(alpha = 0.6f) else CyberCyan.copy(alpha = 0.4f),
                RoundedCornerShape(22.dp)
            )
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = null,
                    tint = if (isRunning) NeonGreen else CyberCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isRunning) "النافذة العائمة قيد التشغيل" else "النافذة العائمة الشفافة (Overlay)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "تظهر فوق جميع الألعاب دون تعطيل اللمس أو التأثير على الأداء",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Action Button
            Button(
                onClick = onToggleOverlay,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_toggle_overlay_main"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRunning) DangerRed else NeonGreen,
                    contentColor = if (isRunning) Color.White else Color.Black
                )
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        isRunning -> "إيقاف النافذة العائمة"
                        !hasPermissions -> "منح الصلاحيات وبدء النافذة"
                        else -> "بدء العرض العائم فوق الألعاب"
                    },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun BlueprintInfoCard() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0F172A).copy(alpha = 0.6f))
            .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = CyberCyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "آلية القياس الفعلي المستقلة عن VSYNC",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "يستخدم التطبيق شاشة وهمية مصغرة (VirtualDisplay 1x1 بكسل) مع ImageReader و System.nanoTime(). كل إطار ترسله اللعبة يتم تسجيله فوراً دون تخزين صور. عند توقف اللعبة لأكثر من 500ms يتم تفعيل كاشف التجميد وعرض 0 FPS بدقة.",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
