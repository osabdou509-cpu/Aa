package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FpsMetrics
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FlameAmber
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun FpsSpeedometerGauge(
    metrics: FpsMetrics,
    maxDisplayFps: Float = 144f,
    modifier: Modifier = Modifier
) {
    val animatedFps by animateFloatAsState(
        targetValue = metrics.averageFps,
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "fpsAnimation"
    )

    val progress = (animatedFps / maxDisplayFps).coerceIn(0f, 1f)

    val statusColor by animateColorAsState(
        targetValue = when {
            metrics.isFrozen || metrics.averageFps == 0f -> DangerRed
            metrics.averageFps >= 60f -> NeonGreen
            metrics.averageFps >= 30f -> FlameAmber
            else -> DangerRed
        },
        label = "statusColor"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("speedometer_gauge_card")
            .clip(RoundedCornerShape(24.dp))
            .background(CyberSurface)
            .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(24.dp))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Speedometer Canvas Arc
            Box(
                modifier = Modifier
                    .size(240.dp, 160.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(230.dp, 150.dp)) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height
                    val strokeWidth = 14.dp.toPx()
                    val arcSize = Size(canvasWidth - strokeWidth, (canvasHeight * 1.8f) - strokeWidth)
                    val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)

                    // Track Background Arc (200 degrees from 170 deg to 370 deg)
                    val startAngle = 170f
                    val sweepAngle = 200f

                    drawArc(
                        color = Color(0xFF1E293B),
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )

                    // Active Arc Gradient
                    val activeSweep = sweepAngle * progress
                    if (activeSweep > 0f) {
                        drawArc(
                            brush = Brush.sweepGradient(
                                0.0f to DangerRed,
                                0.3f to FlameAmber,
                                0.6f to NeonGreen,
                                1.0f to CyberCyan,
                                center = Offset(canvasWidth / 2, canvasHeight * 0.9f)
                            ),
                            startAngle = startAngle,
                            sweepAngle = activeSweep,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }

                    // Ticks around arc
                    val numTicks = 9
                    val radius = (canvasWidth - strokeWidth) / 2
                    val centerX = canvasWidth / 2
                    val centerY = canvasHeight * 0.9f

                    for (i in 0..numTicks) {
                        val tickAngle = Math.toRadians((startAngle + (sweepAngle * (i.toFloat() / numTicks))).toDouble())
                        val tickStartR = radius - 16.dp.toPx()
                        val tickEndR = radius - 8.dp.toPx()

                        val x1 = centerX + (tickStartR * cos(tickAngle)).toFloat()
                        val y1 = centerY + (tickStartR * sin(tickAngle)).toFloat()
                        val x2 = centerX + (tickEndR * cos(tickAngle)).toFloat()
                        val y2 = centerY + (tickEndR * sin(tickAngle)).toFloat()

                        val isHighlighted = (i.toFloat() / numTicks) <= progress
                        drawLine(
                            color = if (isHighlighted) statusColor else Color(0xFF334155),
                            start = Offset(x1, y1),
                            end = Offset(x2, y2),
                            strokeWidth = if (i % 2 == 0) 2.5.dp.toPx() else 1.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Center Digital Readout
                Column(
                    modifier = Modifier.padding(top = 35.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${animatedFps.roundToInt()}",
                        fontSize = 58.sp,
                        fontWeight = FontWeight.Black,
                        color = statusColor,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = (-1).sp
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "FPS",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "MAX ${maxDisplayFps.toInt()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = CyberCyan
                        )
                    }
                }
            }

            // Engine Status Pill
            val statusText = when {
                metrics.isFrozen -> "توقف الإطارات (0 FPS Freeze)"
                metrics.isVirtualDisplayActive -> "شاشة وهمية 1x1 نشطة (دقة مطلقة)"
                else -> "معاينة داخلية نشطة (In-App Preview)"
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(statusColor.copy(alpha = 0.15f))
                    .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = statusColor
                    )
                }
            }
        }
    }
}
