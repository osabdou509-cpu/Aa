package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.data.ColorThemeOption
import com.example.data.OverlayConfig
import com.example.data.OverlaySize
import com.example.engine.FpsMeasurementEngine
import com.example.engine.MediaProjectionHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

class FpsOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var windowLayoutParams: WindowManager.LayoutParams? = null

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var updateJob: Job? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_LOCK -> {
                val newLockState = !isTouchLockedState.value
                setTouchLocked(newLockState)
                updateNotification()
                return START_STICKY
            }
            ACTION_UPDATE_CONFIG -> {
                applyConfigToOverlay(currentConfig.value)
                return START_STICKY
            }
            ACTION_START -> {
                startForegroundWithMediaProjection()
            }
        }

        return START_STICKY
    }

    private fun startForegroundWithMediaProjection() {
        val notification = buildNotification(isTouchLockedState.value)
        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else {
            0
        }

        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            foregroundType
        )

        // Initialize MediaProjection VirtualDisplay
        val resultCode = MediaProjectionHolder.resultCode
        val resultData = MediaProjectionHolder.resultData

        if (resultCode != 0 && resultData != null) {
            try {
                val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val projection = mpManager.getMediaProjection(resultCode, resultData)
                if (projection != null) {
                    FpsMeasurementEngine.instance.startVirtualDisplay(projection)
                }
            } catch (e: Exception) {
                // Fallback to in-app preview mode if system rejected
                e.printStackTrace()
            }
        }

        setupOverlayWindow()
        startMetricsUpdateLoop()
        _isServiceRunning.value = true
    }

    private fun setupOverlayWindow() {
        if (overlayView != null) return

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_fps, null)

        val isLocked = isTouchLockedState.value
        val initialFlags = if (isLocked) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            initialFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 120
        }

        windowLayoutParams = params

        setupDragListener(overlayView!!, params)
        applyConfigToOverlay(currentConfig.value)

        try {
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupDragListener(view: View, params: WindowManager.LayoutParams) {
        view.setOnTouchListener { _, event ->
            if (isTouchLockedState.value) {
                return@setOnTouchListener false
            }

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    try {
                        windowManager?.updateViewLayout(overlayView, params)
                    } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    fun setTouchLocked(locked: Boolean) {
        isTouchLockedState.value = locked
        val params = windowLayoutParams ?: return
        val wm = windowManager ?: return
        val view = overlayView ?: return

        params.flags = if (locked) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        }

        val tvDragHandle = view.findViewById<TextView>(R.id.tv_drag_handle)
        tvDragHandle?.visibility = if (locked) View.GONE else View.VISIBLE

        try {
            wm.updateViewLayout(view, params)
        } catch (_: Exception) {}
    }

    private fun applyConfigToOverlay(config: OverlayConfig) {
        val view = overlayView ?: return
        val tvOnePercentLow = view.findViewById<TextView>(R.id.tv_one_percent_low)
        val tvFrametime = view.findViewById<TextView>(R.id.tv_frametime)
        val extraLayout = view.findViewById<View>(R.id.layout_extra_metrics)
        val tvDragHandle = view.findViewById<TextView>(R.id.tv_drag_handle)

        when (config.size) {
            OverlaySize.COMPACT -> {
                extraLayout?.visibility = View.GONE
            }
            OverlaySize.STANDARD -> {
                extraLayout?.visibility = View.VISIBLE
                tvOnePercentLow?.visibility = if (config.showOnePercentLow) View.VISIBLE else View.GONE
                tvFrametime?.visibility = if (config.showFrameTime) View.VISIBLE else View.GONE
            }
            OverlaySize.DETAILED -> {
                extraLayout?.visibility = View.VISIBLE
                tvOnePercentLow?.visibility = View.VISIBLE
                tvFrametime?.visibility = View.VISIBLE
            }
        }

        tvDragHandle?.visibility = if (isTouchLockedState.value) View.GONE else View.VISIBLE

        // Semi-transparent background (50% - 85% alpha)
        val container = view.findViewById<View>(R.id.overlay_container)
        val alphaInt = (config.alpha.coerceIn(0.4f, 0.85f) * 255).toInt()
        val bgDrawable = GradientDrawable().apply {
            cornerRadius = 32f
            setColor(Color.argb(alphaInt, 9, 13, 22))
            setStroke(2, Color.argb(120, Color.red(config.colorTheme.hexColorInt), Color.green(config.colorTheme.hexColorInt), Color.blue(config.colorTheme.hexColorInt)))
        }
        container.background = bgDrawable
    }

    private fun startMetricsUpdateLoop() {
        updateJob?.cancel()
        updateJob = serviceScope.launch {
            val tvFps = overlayView?.findViewById<TextView>(R.id.tv_fps_value)
            val tvOnePercent = overlayView?.findViewById<TextView>(R.id.tv_one_percent_low)
            val tvFrametime = overlayView?.findViewById<TextView>(R.id.tv_frametime)

            while (isActive) {
                val metrics = FpsMeasurementEngine.instance.metrics.value
                val config = currentConfig.value

                if (tvFps != null) {
                    val fpsInt = metrics.averageFps.roundToInt()
                    tvFps.text = fpsInt.toString()

                    // Dynamic color coding
                    val textColor = when {
                        metrics.isFrozen || fpsInt == 0 -> Color.parseColor("#FF5252") // Red alert for frozen
                        fpsInt >= 60 -> config.colorTheme.hexColorInt
                        fpsInt >= 30 -> Color.parseColor("#FFB300") // Amber
                        else -> Color.parseColor("#FF5252") // Red
                    }
                    tvFps.setTextColor(textColor)
                }

                if (tvOnePercent != null && tvOnePercent.visibility == View.VISIBLE) {
                    val lowInt = metrics.onePercentLowFps.roundToInt()
                    tvOnePercent.text = "1%: $lowInt"
                }

                if (tvFrametime != null && tvFrametime.visibility == View.VISIBLE) {
                    tvFrametime.text = String.format(Locale.US, "%.1fms", metrics.frameTimeMs)
                }

                delay(config.updateIntervalMs.coerceAtLeast(200L))
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "FPS Beta Floating Overlay Notification"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(isLocked: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleLockIntent = Intent(this, FpsOverlayService::class.java).apply {
            action = ACTION_TOGGLE_LOCK
        }
        val toggleLockPendingIntent = PendingIntent.getService(
            this,
            1,
            toggleLockIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FpsOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val lockTitle = if (isLocked) "إلغاء القفل (تحريك)" else "قفل اللمس (اختراق)"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("fps beta • عداد الإطارات الفعلي")
            .setContentText(if (isLocked) "النافذة مغلقة وتخترق اللمس 100%" else "النافذة قابلة للتحريك والسحب")
            .setSmallIcon(R.drawable.fps_meter_icon_1794253125474)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .addAction(0, lockTitle, toggleLockPendingIntent)
            .addAction(0, "إيقاف", stopPendingIntent)
            .build()
    }

    private fun updateNotification() {
        val notification = buildNotification(isTouchLockedState.value)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        updateJob?.cancel()
        FpsMeasurementEngine.instance.stopVirtualDisplay()

        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (_: Exception) {}
            overlayView = null
        }
        _isServiceRunning.value = false
    }

    companion object {
        const val CHANNEL_ID = "fps_overlay_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.fpsbeta.START"
        const val ACTION_STOP = "com.example.fpsbeta.STOP"
        const val ACTION_TOGGLE_LOCK = "com.example.fpsbeta.TOGGLE_LOCK"
        const val ACTION_UPDATE_CONFIG = "com.example.fpsbeta.UPDATE_CONFIG"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning = _isServiceRunning.asStateFlow()

        val isTouchLockedState = MutableStateFlow(true)
        val currentConfig = MutableStateFlow(OverlayConfig())

        fun start(context: Context) {
            val intent = Intent(context, FpsOverlayService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FpsOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun toggleLock(context: Context) {
            val intent = Intent(context, FpsOverlayService::class.java).apply {
                action = ACTION_TOGGLE_LOCK
            }
            context.startService(intent)
        }

        fun updateConfig(context: Context, config: OverlayConfig) {
            currentConfig.value = config
            val intent = Intent(context, FpsOverlayService::class.java).apply {
                action = ACTION_UPDATE_CONFIG
            }
            context.startService(intent)
        }
    }
}
