package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FpsMetrics
import com.example.data.OverlayConfig
import com.example.engine.FpsMeasurementEngine
import com.example.engine.MediaProjectionHolder
import com.example.service.FpsOverlayService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FpsViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = FpsMeasurementEngine.instance

    val metrics: StateFlow<FpsMetrics> = engine.metrics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FpsMetrics())

    val isOverlayServiceRunning: StateFlow<Boolean> = FpsOverlayService.isServiceRunning

    val isTouchLocked: StateFlow<Boolean> = FpsOverlayService.isTouchLockedState

    val hasMediaProjectionPermission: StateFlow<Boolean> = MediaProjectionHolder.hasPermission

    private val _hasOverlayPermission = MutableStateFlow(false)
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _hasNotificationPermission = MutableStateFlow(true)
    val hasNotificationPermission: StateFlow<Boolean> = _hasNotificationPermission.asStateFlow()

    private val _overlayConfig = MutableStateFlow(OverlayConfig())
    val overlayConfig: StateFlow<OverlayConfig> = _overlayConfig.asStateFlow()

    init {
        refreshPermissions()
        // Start in-app frame preview
        engine.startChoreographerPreview()
    }

    fun refreshPermissions() {
        val context = getApplication<Application>()
        _hasOverlayPermission.value = Settings.canDrawOverlays(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionStatus = ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
            _hasNotificationPermission.value = (permissionStatus == android.content.pm.PackageManager.PERMISSION_GRANTED)
        } else {
            _hasNotificationPermission.value = true
        }
    }

    fun onMediaProjectionResult(resultCode: Int, data: Intent?) {
        MediaProjectionHolder.setProjectionData(resultCode, data)
        // If overlay service is already running or user wanted to start, restart projection
        if (FpsOverlayService.isServiceRunning.value) {
            FpsOverlayService.start(getApplication())
        }
    }

    fun toggleOverlayService() {
        val context = getApplication<Application>()
        if (isOverlayServiceRunning.value) {
            FpsOverlayService.stop(context)
        } else {
            FpsOverlayService.start(context)
        }
    }

    fun toggleTouchLock() {
        FpsOverlayService.toggleLock(getApplication())
    }

    fun updateOverlayConfig(config: OverlayConfig) {
        _overlayConfig.value = config
        FpsOverlayService.updateConfig(getApplication(), config)
    }

    fun setSimulationTargetFps(fps: Int?) {
        engine.setSimulationTargetFps(fps)
    }

    fun triggerSimulatedFreeze() {
        engine.triggerSimulatedFreeze(2000L)
    }

    override fun onCleared() {
        super.onCleared()
        engine.stopChoreographerPreview()
    }
}
