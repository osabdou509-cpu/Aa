package com.example.data

import androidx.compose.ui.graphics.Color

data class FpsMetrics(
    val averageFps: Float = 0f,
    val instantFps: Float = 0f,
    val onePercentLowFps: Float = 0f,
    val frameTimeMs: Float = 0f,
    val frameCount: Long = 0L,
    val isFrozen: Boolean = false,
    val isVirtualDisplayActive: Boolean = false,
    val history: List<Float> = emptyList()
)

enum class OverlaySize(val labelAr: String, val labelEn: String) {
    COMPACT("مضغوط", "Compact"),
    STANDARD("قياسي", "Standard"),
    DETAILED("تفصيلي", "Detailed")
}

enum class ColorThemeOption(
    val title: String,
    val primaryColor: Color,
    val hexColorInt: Int
) {
    NEON_GREEN("أخضر نيون", Color(0xFF00E676), 0xFF00E676.toInt()),
    CYBER_CYAN("سايبر سماوي", Color(0xFF00E5FF), 0xFF00E5FF.toInt()),
    ELECTRIC_PURPLE("بنفسجي مشع", Color(0xFFB388FF), 0xFFB388FF.toInt()),
    FLAME_AMBER("كهرماني ناري", Color(0xFFFFB300), 0xFFFFB300.toInt())
}

data class OverlayConfig(
    val size: OverlaySize = OverlaySize.STANDARD,
    val colorTheme: ColorThemeOption = ColorThemeOption.NEON_GREEN,
    val alpha: Float = 0.65f,
    val showOnePercentLow: Boolean = true,
    val showFrameTime: Boolean = true,
    val isTouchLocked: Boolean = true,
    val updateIntervalMs: Long = 400L
)
