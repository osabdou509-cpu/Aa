package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.FpsMeasurementEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("fps beta", appName)
    }

    @Test
    fun `verify fps measurement engine initialized`() {
        val engine = FpsMeasurementEngine.instance
        assertNotNull(engine)
        val metrics = engine.metrics.value
        assertEquals(0f, metrics.averageFps, 0.01f)
    }
}
